package com.example.dsm01investigacion

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import androidx.appcompat.app.AppCompatActivity
import android.widget.CheckBox
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    /* Vistas de la interfaz */
    private lateinit var editTextTask: EditText
    private lateinit var buttonAddTask: Button
    private lateinit var listViewTasks: ListView

    /* Lista de tareas Y posiciones de elementos seleccionados */
    private val tasks = mutableListOf<String>()
    private val checkedPositions = mutableSetOf<Int>()

    /* Adaptador para la lista de tareas */
    private lateinit var adapter: TaskAdapter

    /* SharedPreferences para guardar y recuperar datos */
    private lateinit var sharedPreferences: SharedPreferences
    private val tasksKey = "tasks_key"
    private val checkedPositionsKey = "checked_positions_key"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /* Inicialización de las vistas */
        editTextTask = findViewById(R.id.editTextTask)
        buttonAddTask = findViewById(R.id.buttonAddTask)
        listViewTasks = findViewById(R.id.listViewTasks)

        /* Inicialización de SharedPreferences */
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        /* Recuperar tareas guardadas */
        loadTasks()

        /* Adaptador para la lista */
        adapter = TaskAdapter(this, tasks, checkedPositions)
        listViewTasks.adapter = adapter

        /* Acción del botón */
        buttonAddTask.setOnClickListener {
            val task = editTextTask.text.toString()
            if (task.isNotBlank()) {
                tasks.add(task)
                adapter.notifyDataSetChanged()
                editTextTask.text.clear()
                saveTasks()
            }
        }

        /* Configurar la acción al mantener presionado un elemento de la lista */
        listViewTasks.setOnItemLongClickListener { _, _, position, _ ->
            val taskToRemove = tasks[position]

            // Mostrar un cuadro de diálogo para confirmar la eliminación de una tarea
            val alertDialog = AlertDialog.Builder(this)
                .setTitle("Eliminar Tarea")
                .setMessage("¿Estás seguro de que deseas eliminar esta tarea?")
                .setPositiveButton("Sí") { _, _ ->
                    tasks.remove(taskToRemove)
                    adapter.notifyDataSetChanged()
                    saveTasks()
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.cancel()
                }
                .create()
            alertDialog.show()
            true
        }

}




/* Guardar las tareas y posiciones de elementos seleccionados en SharedPreferences */
    private fun saveTasks() {
        val gson = Gson()
        val jsonTasks = gson.toJson(tasks)
        val jsonCheckedPositions = gson.toJson(checkedPositions)
        sharedPreferences.edit()
            .putString(tasksKey, jsonTasks)
            .putString(checkedPositionsKey, jsonCheckedPositions)
            .apply()
    }

    /* Cargar las tareas y posiciones de elementos seleccionados desde SharedPreferences */
    private fun loadTasks() {
        val gson = Gson()
        val jsonTasks = sharedPreferences.getString(tasksKey, null)
        val jsonCheckedPositions = sharedPreferences.getString(checkedPositionsKey, null)
        val typeTasks = object : TypeToken<MutableList<String>>() {}.type
        val typeCheckedPositions = object : TypeToken<MutableSet<Int>>() {}.type
        val savedTasks: MutableList<String>? = gson.fromJson(jsonTasks, typeTasks)
        val savedCheckedPositions: MutableSet<Int>? = gson.fromJson(jsonCheckedPositions, typeCheckedPositions)
        if (savedTasks != null) {
            tasks.clear()
            tasks.addAll(savedTasks)
        }
        if (savedCheckedPositions != null) {
            checkedPositions.clear()
            checkedPositions.addAll(savedCheckedPositions)
        }
    }

    /*
       •	Cada tarea debe mostrar un checkbox para marcarla como completada
       •	Las tareas marcadas como completadas deben mostrarse de forma diferente (por ejemplo, tachadas)
     */

    /* Adaptador personalizado para la lista de tareas */
    private class TaskAdapter(context: Context, private val tasks: MutableList<String>, private val checkedPositions: MutableSet<Int>) : BaseAdapter() {
        private val inflater: LayoutInflater = LayoutInflater.from(context)

        override fun getCount(): Int = tasks.size
        override fun getItem(position: Int): String = tasks[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View = convertView ?: inflater.inflate(R.layout.list_item, parent, false)
            val task = getItem(position)

            /* Inicialización del CheckBox */
            val checkBox: CheckBox = view.findViewById(R.id.checkBoxTask)

            val textView: TextView = view.findViewById(R.id.textViewTask)

            /* Configurar el estado del CheckBox y su comportamiento */
            checkBox.isChecked = checkedPositions.contains(position)
            checkBox.setOnClickListener {
                if (checkBox.isChecked) {
                    checkedPositions.add(position)
                } else {
                    checkedPositions.remove(position)
                }
                notifyDataSetChanged()
            }

            /* Aquí aplica o quita el efecto de tachado en el texto basado en el estado del CheckBox */
            if (checkBox.isChecked) {
                textView.paintFlags = textView.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                textView.paintFlags = textView.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }

            textView.text = task

            /*
                Si el CheckBox está marcado, se añade la bandera STRIKE_THRU_TEXT_FLAG a las PaintFlags del TextView, lo que hace que el texto se muestre tachado
                y si en el dado caso que  el CheckBox no está marcado, se elimina la bandera STRIKE_THRU_TEXT_FLAG, y el texto ya no se muestra tachado
            */
            return view
        }
    }
}
